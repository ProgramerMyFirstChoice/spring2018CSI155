﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeApr3AccountManager
{
	public class SportCar : Car
	{
		public string ZeroToSixty { get; set; } = nameof(SportCar);
		//public string Make { get; set; }
		//public string Model { get; set; }
		//public int Mileage { get; set; }
		//public int Year { get; set; }
		//public decimal Price { get; set; }
		//public string EngineSize { get; set; }
		//public int AverageMPG { get; set; }
		//public int SalesPersonID { get; set; }

		//public SportCar() : base() { }

		public SportCar(string make, string model, int mileage, int year, decimal price, string engineSize,
			int averageMPG, int salesPersonID, string zeroToSixty/*, string descriptionZerroToSixty, string descriptionMaxTowing*/)
			: base(make, model, mileage, year, price, engineSize, averageMPG, salesPersonID/*, descriptionZerroToSixty, 
				  descriptionMaxTowing*/)
		{
			//Make = make;
			//Model = model;
			//Mileage = mileage;
			//Year = year;
			//Price = price;
			//EngineSize = engineSize;
			//AverageMPG = averageMPG;
			//SalesPersonID = salesPersonID;
			ZeroToSixty = zeroToSixty;
		}

		//public override string GetZeroToSixty(string sec) => Make + sec + Model + sec + Mileage.ToString()
		//	+ sec + Year + sec + Price + sec + EngineSize + sec + AverageMPG/* + sec + SalesPersonID
		//	+ sec + DescriptionZeroToSixty*/;

		
	}
}
