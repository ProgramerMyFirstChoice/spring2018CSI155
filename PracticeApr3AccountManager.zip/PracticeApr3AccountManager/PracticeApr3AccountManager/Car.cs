﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeApr3AccountManager
{
	public class Car : IVehicle
	{
		//public string MaxTowing { get; set; } = nameof(Car);

		//public Car() : base() { }
        public string Make { get; set; }
		public string Model { get; set; }
		public int Mileage { get; set; }
		public int Year { get; set; }
		public decimal Price { get; set; }
		public string EngineSize { get; set; }
		public int AverageMPG { get; set; }
		public int SalesPersonID { get; set; }

		public Car(string make, string model, int mileage, int year, decimal price, string engineSize, int averageMPG, int salesPersonID)
			//: base(make, model, mileage, year, price, engineSize, averageMPG, salesPersonID)
		{
			Make = make;
			Model = model;
			Mileage = mileage;
			Year = year;
			Price = price;
			EngineSize = engineSize;
			AverageMPG = averageMPG;
			SalesPersonID = salesPersonID;
		}/*, string descriptionZerroToSixty, string descriptionMaxTowing*/	
		
		
		//: base(make, model, mileage, year, price, engineSize, averageMPG, salesPersonID/*, descriptionZerroToSixty, descriptionMaxTowing*/) { }
		//public Vehicle MaxPrice(List<Vehicle> veh)
		//{
		//	Vehicle vehicles = new Vehicle();
		//	decimal mixPrice = veh[0].Price;
		//	foreach (Vehicle c in veh)
		//	{
		//		if (c.Price > mixPrice)
		//		{
		//			mixPrice = c.Price;
		//			vehicles.Make = c.Make;
		//			vehicles.Model = c.Model;
		//			vehicles.Mileage = c.Mileage;
		//			vehicles.Year = c.Year;
		//			vehicles.Price = c.Price;
		//			vehicles.EngineSize = c.EngineSize;
		//			vehicles.AverageMPG = c.AverageMPG;
		//			vehicles.SalesPersonID = c.SalesPersonID;
		//		}
		//	}
		//	return nyll;
		//}
	}
	}
