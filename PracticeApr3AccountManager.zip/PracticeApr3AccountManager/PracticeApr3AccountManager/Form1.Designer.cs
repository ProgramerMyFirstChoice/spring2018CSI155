﻿namespace PracticeApr3AccountManager
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lvDisplay = new System.Windows.Forms.ListView();
			this.columnMake = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnModel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnMileage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnEngeneSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnAverageMPG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnSalesPersonID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnZeroToSixty = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnMaxTowing = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.lblSelectPerson = new System.Windows.Forms.Label();
			this.cmbSelectPerson = new System.Windows.Forms.ComboBox();
			this.btnSelectPerson = new System.Windows.Forms.Button();
			this.grbSalesPersone = new System.Windows.Forms.GroupBox();
			this.grpBoxVahicleType = new System.Windows.Forms.GroupBox();
			this.btnSelectVehicle = new System.Windows.Forms.Button();
			this.cmbBoxSelectVehicle = new System.Windows.Forms.ComboBox();
			this.lblSelectVehicle = new System.Windows.Forms.Label();
			this.btnDisplayAllVehicle = new System.Windows.Forms.Button();
			this.btnMostExpensiveVehicle = new System.Windows.Forms.Button();
			this.btnClearList = new System.Windows.Forms.Button();
			this.grbSalesPersone.SuspendLayout();
			this.grpBoxVahicleType.SuspendLayout();
			this.SuspendLayout();
			// 
			// lvDisplay
			// 
			this.lvDisplay.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.lvDisplay.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnMake,
            this.columnModel,
            this.columnMileage,
            this.columnYear,
            this.columnPrice,
            this.columnEngeneSize,
            this.columnAverageMPG,
            this.columnSalesPersonID,
            this.columnZeroToSixty,
            this.columnMaxTowing});
			this.lvDisplay.GridLines = true;
			this.lvDisplay.Location = new System.Drawing.Point(12, 12);
			this.lvDisplay.Name = "lvDisplay";
			this.lvDisplay.Size = new System.Drawing.Size(852, 317);
			this.lvDisplay.TabIndex = 0;
			this.lvDisplay.UseCompatibleStateImageBehavior = false;
			this.lvDisplay.View = System.Windows.Forms.View.Details;
			// 
			// columnMake
			// 
			this.columnMake.Text = "Vehicle Make";
			this.columnMake.Width = 131;
			// 
			// columnModel
			// 
			this.columnModel.Text = "Model";
			this.columnModel.Width = 114;
			// 
			// columnMileage
			// 
			this.columnMileage.Text = "Mileage";
			this.columnMileage.Width = 111;
			// 
			// columnYear
			// 
			this.columnYear.Text = "Year";
			this.columnYear.Width = 64;
			// 
			// columnPrice
			// 
			this.columnPrice.Text = "Price";
			this.columnPrice.Width = 79;
			// 
			// columnEngeneSize
			// 
			this.columnEngeneSize.Text = "Engene Size";
			this.columnEngeneSize.Width = 83;
			// 
			// columnAverageMPG
			// 
			this.columnAverageMPG.Text = "MPG";
			this.columnAverageMPG.Width = 61;
			// 
			// columnSalesPersonID
			// 
			this.columnSalesPersonID.Text = "Saler ID";
			this.columnSalesPersonID.Width = 59;
			// 
			// columnZeroToSixty
			// 
			this.columnZeroToSixty.Text = "Zero to Sixty";
			this.columnZeroToSixty.Width = 73;
			// 
			// columnMaxTowing
			// 
			this.columnMaxTowing.Text = "Max Towing";
			this.columnMaxTowing.Width = 73;
			// 
			// lblSelectPerson
			// 
			this.lblSelectPerson.AutoSize = true;
			this.lblSelectPerson.Location = new System.Drawing.Point(6, 22);
			this.lblSelectPerson.Name = "lblSelectPerson";
			this.lblSelectPerson.Size = new System.Drawing.Size(127, 13);
			this.lblSelectPerson.TabIndex = 1;
			this.lblSelectPerson.Text = "Select Employee from list:";
			// 
			// cmbSelectPerson
			// 
			this.cmbSelectPerson.FormattingEnabled = true;
			this.cmbSelectPerson.Location = new System.Drawing.Point(153, 19);
			this.cmbSelectPerson.Name = "cmbSelectPerson";
			this.cmbSelectPerson.Size = new System.Drawing.Size(121, 21);
			this.cmbSelectPerson.TabIndex = 9;
			// 
			// btnSelectPerson
			// 
			this.btnSelectPerson.Location = new System.Drawing.Point(107, 63);
			this.btnSelectPerson.Name = "btnSelectPerson";
			this.btnSelectPerson.Size = new System.Drawing.Size(167, 23);
			this.btnSelectPerson.TabIndex = 10;
			this.btnSelectPerson.Text = "Select Person By ID";
			this.btnSelectPerson.UseVisualStyleBackColor = true;
			this.btnSelectPerson.Click += new System.EventHandler(this.btnSelectPerson_Click);
			// 
			// grbSalesPersone
			// 
			this.grbSalesPersone.Controls.Add(this.btnSelectPerson);
			this.grbSalesPersone.Controls.Add(this.cmbSelectPerson);
			this.grbSalesPersone.Controls.Add(this.lblSelectPerson);
			this.grbSalesPersone.Location = new System.Drawing.Point(12, 335);
			this.grbSalesPersone.Name = "grbSalesPersone";
			this.grbSalesPersone.Size = new System.Drawing.Size(280, 100);
			this.grbSalesPersone.TabIndex = 3;
			this.grbSalesPersone.TabStop = false;
			this.grbSalesPersone.Text = "Sale Person";
			// 
			// grpBoxVahicleType
			// 
			this.grpBoxVahicleType.Controls.Add(this.btnSelectVehicle);
			this.grpBoxVahicleType.Controls.Add(this.cmbBoxSelectVehicle);
			this.grpBoxVahicleType.Controls.Add(this.lblSelectVehicle);
			this.grpBoxVahicleType.Location = new System.Drawing.Point(298, 335);
			this.grpBoxVahicleType.Name = "grpBoxVahicleType";
			this.grpBoxVahicleType.Size = new System.Drawing.Size(280, 100);
			this.grpBoxVahicleType.TabIndex = 11;
			this.grpBoxVahicleType.TabStop = false;
			this.grpBoxVahicleType.Text = "Vahicle Type";
			// 
			// btnSelectVehicle
			// 
			this.btnSelectVehicle.Location = new System.Drawing.Point(107, 63);
			this.btnSelectVehicle.Name = "btnSelectVehicle";
			this.btnSelectVehicle.Size = new System.Drawing.Size(167, 23);
			this.btnSelectVehicle.TabIndex = 10;
			this.btnSelectVehicle.Text = "Select Vehicle By Type";
			this.btnSelectVehicle.UseVisualStyleBackColor = true;
			this.btnSelectVehicle.Click += new System.EventHandler(this.btnSelectVehicle_Click);
			// 
			// cmbBoxSelectVehicle
			// 
			this.cmbBoxSelectVehicle.FormattingEnabled = true;
			this.cmbBoxSelectVehicle.Location = new System.Drawing.Point(153, 19);
			this.cmbBoxSelectVehicle.Name = "cmbBoxSelectVehicle";
			this.cmbBoxSelectVehicle.Size = new System.Drawing.Size(121, 21);
			this.cmbBoxSelectVehicle.TabIndex = 9;
			// 
			// lblSelectVehicle
			// 
			this.lblSelectVehicle.AutoSize = true;
			this.lblSelectVehicle.Location = new System.Drawing.Point(6, 22);
			this.lblSelectVehicle.Name = "lblSelectVehicle";
			this.lblSelectVehicle.Size = new System.Drawing.Size(114, 13);
			this.lblSelectVehicle.TabIndex = 1;
			this.lblSelectVehicle.Text = "Select vehicle by type:";
			// 
			// btnDisplayAllVehicle
			// 
			this.btnDisplayAllVehicle.Location = new System.Drawing.Point(696, 378);
			this.btnDisplayAllVehicle.Name = "btnDisplayAllVehicle";
			this.btnDisplayAllVehicle.Size = new System.Drawing.Size(168, 23);
			this.btnDisplayAllVehicle.TabIndex = 12;
			this.btnDisplayAllVehicle.Text = "Display All Vehicle";
			this.btnDisplayAllVehicle.UseVisualStyleBackColor = true;
			this.btnDisplayAllVehicle.Click += new System.EventHandler(this.btnDisplayAllVehicle_Click);
			// 
			// btnMostExpensiveVehicle
			// 
			this.btnMostExpensiveVehicle.Location = new System.Drawing.Point(696, 349);
			this.btnMostExpensiveVehicle.Name = "btnMostExpensiveVehicle";
			this.btnMostExpensiveVehicle.Size = new System.Drawing.Size(168, 23);
			this.btnMostExpensiveVehicle.TabIndex = 13;
			this.btnMostExpensiveVehicle.Text = "Most Expensive Vehicle";
			this.btnMostExpensiveVehicle.UseVisualStyleBackColor = true;
			this.btnMostExpensiveVehicle.Click += new System.EventHandler(this.btnMostExpensiveVehicle_Click);
			// 
			// btnClearList
			// 
			this.btnClearList.Location = new System.Drawing.Point(696, 407);
			this.btnClearList.Name = "btnClearList";
			this.btnClearList.Size = new System.Drawing.Size(168, 23);
			this.btnClearList.TabIndex = 14;
			this.btnClearList.Text = "Clear List / Exit Program";
			this.btnClearList.UseVisualStyleBackColor = true;
			this.btnClearList.Click += new System.EventHandler(this.btnClearList_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(875, 442);
			this.Controls.Add(this.btnClearList);
			this.Controls.Add(this.btnMostExpensiveVehicle);
			this.Controls.Add(this.btnDisplayAllVehicle);
			this.Controls.Add(this.grpBoxVahicleType);
			this.Controls.Add(this.grbSalesPersone);
			this.Controls.Add(this.lvDisplay);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.grbSalesPersone.ResumeLayout(false);
			this.grbSalesPersone.PerformLayout();
			this.grpBoxVahicleType.ResumeLayout(false);
			this.grpBoxVahicleType.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ListView lvDisplay;
		private System.Windows.Forms.ColumnHeader columnMake;
		private System.Windows.Forms.ColumnHeader columnModel;
		private System.Windows.Forms.ColumnHeader columnMileage;
		private System.Windows.Forms.Label lblSelectPerson;
		private System.Windows.Forms.ComboBox cmbSelectPerson;
		private System.Windows.Forms.Button btnSelectPerson;
		private System.Windows.Forms.GroupBox grbSalesPersone;
		private System.Windows.Forms.GroupBox grpBoxVahicleType;
		private System.Windows.Forms.Button btnSelectVehicle;
		private System.Windows.Forms.ComboBox cmbBoxSelectVehicle;
		private System.Windows.Forms.Label lblSelectVehicle;
		private System.Windows.Forms.Button btnDisplayAllVehicle;
		private System.Windows.Forms.Button btnMostExpensiveVehicle;
		private System.Windows.Forms.Button btnClearList;
		private System.Windows.Forms.ColumnHeader columnYear;
		private System.Windows.Forms.ColumnHeader columnPrice;
		private System.Windows.Forms.ColumnHeader columnEngeneSize;
		private System.Windows.Forms.ColumnHeader columnAverageMPG;
		private System.Windows.Forms.ColumnHeader columnSalesPersonID;
		private System.Windows.Forms.ColumnHeader columnZeroToSixty;
		private System.Windows.Forms.ColumnHeader columnMaxTowing;
	}
}

