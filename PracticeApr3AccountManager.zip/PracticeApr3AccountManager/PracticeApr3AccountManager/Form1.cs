﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PracticeApr3AccountManager
{
	public partial class Form1 : Form
	{
		List<IVehicle> vehicleList = new List<IVehicle>();

		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			ComboBoxes();
			ComboBoxesSalePersonID();

			Car car = new Car("Ford", "Mustang", 12300, 2018, 96345, "v8", 25, 106);
			vehicleList.Add(car);
			car = new Car("Shevrolet", "Corvette", 22300, 2018, 85495, "v8", 25, 107);
			vehicleList.Add(car);
			car = new Car("Doage", "Challenger", 8300, 2018, 93995, "v10", 30, 108);
			vehicleList.Add(car);
			car = new Car("Audi", "R8 Coupe", 19300, 2018, 147500, "v8", 25, 109);
			vehicleList.Add(car);
			car = new Car("BMW", "i8 Roadster", 10300, 2018, 147500, "Electric", 25, 103);
			vehicleList.Add(car);

			SportCar sportCar = new SportCar("Ford", "Mustang", 12300, 2018, 96345, "v8", 25, 106, "32");
			vehicleList.Add(sportCar);
			sportCar = new SportCar("Shevrolet", "Corvette", 22300, 2018, 85495, "v8", 25, 107, "23");
			vehicleList.Add(sportCar);
			sportCar = new SportCar("Doage", "Challenger", 8300, 2018, 93995, "v10", 30, 108, "23");
			vehicleList.Add(sportCar);
			sportCar = new SportCar("Audi", "R8 Coupe", 19300, 2018, 147500, "Electric", 25, 109, "32");
			vehicleList.Add(sportCar);
			sportCar = new SportCar("BMW", "i8 Roadster", 10300, 2018, 147500, "v8", 25, 103, "23");
			vehicleList.Add(sportCar);

			Truck truck = new Truck("Ford", "F-150 Raptor", 12300, 2018, 53000, "v6", 18, 107, "12000lb");
			vehicleList.Add(truck);
			truck = new Truck("Toyota", "Tacoma TRD", 26300, 2018, 43000, "v6", 22, 107, "12000lb");
			vehicleList.Add(truck);
			truck = new Truck("Doage", "Ram 3500", 32300, 2018, 53645, "v8", 31, 105, "12000lb");
			vehicleList.Add(truck);
			truck = new Truck("GMC", "Sierra 2500HD", 42300, 2018, 69500, "v8", 36, 109, "12000lb");
			vehicleList.Add(truck);
			truck = new Truck("Chevrolet", "Silverado 3500", 12300, 2018, 40000, "v8", 28, 107, "12000lb");
			vehicleList.Add(truck);
		}

		private void ComboBoxesSalePersonID()
		{
			cmbSelectPerson.Items.Add("Select Employee");
			cmbSelectPerson.Items.Add("101");
			cmbSelectPerson.Items.Add("ID102 Stiven");
			cmbSelectPerson.Items.Add("ID103 Sonia");
			cmbSelectPerson.Items.Add("ID104 Tanor");
			cmbSelectPerson.Items.Add("ID105 Alex");
			cmbSelectPerson.Items.Add("ID106 Zachary");
			cmbSelectPerson.Items.Add("ID107 ");
			cmbSelectPerson.Items.Add("ID108 Type");
			cmbSelectPerson.Items.Add("ID109 Type");
			cmbSelectPerson.Items.Add("ID110 Type");
			cmbSelectPerson.SelectedIndex = 0;
		}

		private void ComboBoxes()
		{
			cmbBoxSelectVehicle.Items.Add("Select Type");
			cmbBoxSelectVehicle.Items.Add("Car");
			cmbBoxSelectVehicle.Items.Add("Sportcar");
			cmbBoxSelectVehicle.Items.Add("Truck");
			cmbBoxSelectVehicle.SelectedIndex = 0;
		}

		private List<Car> GetCarList()
		{
			List<Car> list = new List<Car>();
			list.Add(new Car("Toyota", "Camry", 2000, 2018, 20000, "v6", 45, 101));
			list.Add(new Car("Mazda", "6", 1800, 2018, 45000, "v6", 30, 102));
			list.Add(new Car("Subaru", "Outback", 1800, 2018, 15000, "v6", 30, 103));
			list.Add(new Car("Ford", "X8", 1800, 2018, 65000, "v6", 30, 104));
			list.Add(new Car("Mercury", "Saab", 1800, 2018, 45000, "v6", 30, 105));
			return list;
		}

		private Car CarList()
		{
			var cars = GetCarList();
			foreach (Car c in cars)
			{
				var row = new string[] {c.Make, c.Model, c.Mileage.ToString(), c.Year.ToString(), c.Price.ToString(),
				c.EngineSize, c.AverageMPG.ToString(), c.SalesPersonID.ToString()};
				var lvi = new ListViewItem(row);
				lvi.Tag = cars;
				lvDisplay.Items.Add(lvi);
			}
			return null;
		}

		private List<SportCar> GetSportcarkList()
		{
			List<SportCar> list = new List<SportCar>();
			list.Add(new SportCar("Ford", "Mustang", 12300, 2018, 96345, "v8", 25, 106, "3.1sec"));
			list.Add(new SportCar("Shevrolet", "Corvette", 22300, 2018, 85495, "v8", 25, 107, "3.3sec"));
			list.Add(new SportCar("Doage", "Challenger", 8300, 2018, 93995, "v10", 30, 108, "3.5sec"));
			list.Add(new SportCar("Audi", "R8 Coupe", 19300, 2018, 147500, "Electric", 25, 109, "3.2sec"));
			list.Add(new SportCar("BMW", "i8 Roadster", 10300, 2018, 137500, "v8", 25, 103, "3.3sec"));
			return list;
		}

		private SportCar SportcarList()
		{
			var cars = GetSportcarkList();
			foreach (SportCar c in cars)
			{
				var row = new string[] {c.Make, c.Model, c.Mileage.ToString(), c.Year.ToString(), c.Price.ToString(),
				c.EngineSize, c.AverageMPG.ToString(), c.SalesPersonID.ToString(),c.ZeroToSixty};
				var lvi = new ListViewItem(row);
				lvi.Tag = cars;
				lvDisplay.Items.Add(lvi);
			}
			return null;
		}

		private List<Truck> GetTruckList()
		{
			List<Truck> list = new List<Truck>();
			list.Add(new Truck("Ford", "F-150 Raptor", 12300, 2018, 53000, "v6", 18, 107, "1000lbs"));
			list.Add(new Truck("Toyota", "Tacoma TRD", 26300, 2018, 43000, "v6", 22, 107, "2000lbs"));
			list.Add(new Truck("Doage", "Ram 3500", 32300, 2018, 53645, "v8", 31, 105, "3000lbs"));
			list.Add(new Truck("GMC", "Sierra 2500HD", 42300, 2018, 69500, "v8", 36, 109, "4000lbs"));
			list.Add(new Truck("Chevrolet", "Silverado 3500", 12300, 2018, 40000, "v8", 28, 107, "5000lbs"));
			return list;
		}

		private Truck TruckList()
		{
			var cars = GetTruckList();
			foreach (Truck c in cars)
			{
				var row = new string[] {c.Make, c.Model, c.Mileage.ToString(), c.Year.ToString(), c.Price.ToString(),
				c.EngineSize, c.AverageMPG.ToString(), c.SalesPersonID.ToString(),"", c.MaxTowing};
				var lvi = new ListViewItem(row);
				lvi.Tag = cars;
				lvDisplay.Items.Add(lvi);
			}
			return null;
		}

		public void DisplayVehiclesCar(/*List<Vehicle> list*/)
		{			
			var cars = GetCarList();
			foreach (IVehicle veh in cars)
			{
				var row = new string[] {veh.Make, veh.Model, veh.Mileage.ToString(), veh.Year.ToString(), veh.Price.ToString(),
				veh.EngineSize, veh.AverageMPG.ToString(), veh.SalesPersonID.ToString()};
				var lvi = new ListViewItem(row);
				lvi.Tag = cars;
				lvDisplay.Items.Add(lvi);
			}
			//vehicleList = GetAllList();
			//foreach (Car veh in list)
			//{
			//	ListViewItem value = new ListViewItem(veh.Make);
			//	value.SubItems.Add(veh.Model);
			//	value.SubItems.Add(veh.Mileage.ToString("#,###"));
			//	value.SubItems.Add(veh.Year.ToString());
			//	value.SubItems.Add(veh.Price.ToString("c"));
			//	value.SubItems.Add(veh.EngineSize);
			//	value.SubItems.Add(veh.AverageMPG.ToString());
			//	value.SubItems.Add(veh.SalesPersonID.ToString());
			//	value.Tag = list;
			//	lvDisplay.Items.Add(value);
			//}
		}
		
		public void DisplayVehiclesSportCar(/*List<SportCar> list*/)
		{
			var cars = GetSportcarkList();
			foreach (SportCar veh in cars)
			{
				var row = new string[] {veh.Make, veh.Model, veh.Mileage.ToString(), veh.Year.ToString(), veh.Price.ToString(),
				veh.EngineSize, veh.AverageMPG.ToString(), veh.SalesPersonID.ToString(),veh.ZeroToSixty};
				var lvi = new ListViewItem(row);
				lvi.Tag = cars;
				lvDisplay.Items.Add(lvi);
			}
			//	foreach (SportCar veh in list)
			//{
			//	ListViewItem value = new ListViewItem(veh.Make);
			//	value.SubItems.Add(veh.Model);
			//	value.SubItems.Add(veh.Mileage.ToString("#,###"));
			//	value.SubItems.Add(veh.Year.ToString());
			//	value.SubItems.Add(veh.Price.ToString("c"));
			//	value.SubItems.Add(veh.EngineSize);
			//	value.SubItems.Add(veh.AverageMPG.ToString());
			//	value.SubItems.Add(veh.SalesPersonID.ToString());
			//	//value.SubItems.Add(veh.DescriptionZeroToSixty);							
			//	lvDisplay.Items.Add(value);
			//}
		}

		//public void DisplayVehiclesTruck(List<Vehicle> list)
		//{
		//	foreach (Truck veh in list)
		//	{
		//		ListViewItem value = new ListViewItem(veh.Make);
		//		value.SubItems.Add(veh.Model);
		//		value.SubItems.Add(veh.Mileage.ToString("#,###"));
		//		value.SubItems.Add(veh.Year.ToString());
		//		value.SubItems.Add(veh.Price.ToString("c"));
		//		value.SubItems.Add(veh.EngineSize);
		//		value.SubItems.Add(veh.AverageMPG.ToString());
		//		value.SubItems.Add(veh.SalesPersonID.ToString());
		//		//value.SubItems.Add(veh.DescriptionZeroToSixty);							
		//		lvDisplay.Items.Add(value);
		//	}
		//}

		public void DisplayVehiclesTruck()
		{
			var cars = GetTruckList();
			foreach (Truck veh in cars)
			{
				var row = new string[] {veh.Make, veh.Model, veh.Mileage.ToString(), veh.Year.ToString(), veh.Price.ToString(),
				veh.EngineSize, veh.AverageMPG.ToString(), veh.SalesPersonID.ToString(),"",veh.MaxTowing};
				var lvi = new ListViewItem(row);
				lvi.Tag = cars;
				lvDisplay.Items.Add(lvi);
			}
		}
		
		private List<IVehicle> GetAllList()
		{
			int s = cmbBoxSelectVehicle.SelectedIndex;
			foreach (IVehicle car in vehicleList)
			{
				if (s == 4)
				{
					vehicleList.Add(car);
				}
			}
			return vehicleList;
		}

		public void DisplayVehicles()
		{
			//foreach (Vehicle veh in vehicleList)
			//{				
			//	//if(veh == Truck)
			//	ListViewItem value = new ListViewItem(veh.Make);
			//	value.SubItems.Add(veh.Model);
			//	value.SubItems.Add(veh.Mileage.ToString("#,###"));
			//	value.SubItems.Add(veh.Year.ToString());
			//	value.SubItems.Add(veh.Price.ToString("c"));
			//	value.SubItems.Add(veh.EngineSize);
			//	value.SubItems.Add(veh.AverageMPG.ToString());
			//	value.SubItems.Add(veh.SalesPersonID.ToString());
			//	//value.SubItems.Add(veh.DescriptionZeroToSixty);							
			//	lvDisplay.Items.Add(value);
			//}
		}

		private void GetPersonID(int i)
		{
			lvDisplay.Items.Clear();

			List<IVehicle> id = GetSalerByID(i);
			
			foreach (IVehicle c in id)
			{
				ListViewItem value = new ListViewItem(c.Make.ToString());
				value.SubItems.Add(c.Model);
				value.SubItems.Add(c.Mileage.ToString("#,###"));
				value.SubItems.Add(c.Year.ToString());
				value.SubItems.Add(c.Price.ToString("c"));
				value.SubItems.Add(c.EngineSize);
				value.SubItems.Add(c.AverageMPG.ToString());
				value.SubItems.Add(c.SalesPersonID.ToString());
				//value.Tag = vehicleList;
				lvDisplay.Items.Add(value);
				
			}
			return;
		}

		private List<IVehicle> GetSalerByID(int id)
		{
			List<IVehicle> salePerson = new List<IVehicle>();
			foreach (IVehicle veh in vehicleList)
			{
				if (veh.SalesPersonID == id)
				{
					salePerson.Add(veh);
					
				}
			}
			return salePerson;
		}

		public void SelerID()
		{
			//vehicleList = GetAllList();
			//Vehicle maxB = MaxPrice(vehicleList);
			//foreach (Vehicle veh in vehicleList)
			//{
			//	var row = new string[] {maxB.Make, maxB.Model, maxB.Mileage.ToString(), maxB.Year.ToString(), maxB.Price.ToString(),
			//	maxB.EngineSize, maxB.AverageMPG.ToString(), maxB.SalesPersonID.ToString()};
			//	var lvi = new ListViewItem(row);
			//	lvi.Tag = vehicleList;
			//	lvDisplay.Items.Add(lvi);
			//	return;
			//}			
		}

		private void btnDisplayAllVehicle_Click(object sender, EventArgs e)
		{
			lvDisplay.Items.Clear();
			CarList();			
			SportcarList();
			TruckList();
		}

		private void btnMostExpensiveVehicle_Click(object sender, EventArgs e)
		{			
			try
			{
				lvDisplay.Items.Clear();
				vehicleList = GetAllList();
				IVehicle maxB = MaxPrice(vehicleList);
				foreach (IVehicle veh in vehicleList)
				{
					var row = new string[] {maxB.Make, maxB.Model, maxB.Mileage.ToString(), maxB.Year.ToString(), maxB.Price.ToString(),
				maxB.EngineSize, maxB.AverageMPG.ToString(), maxB.SalesPersonID.ToString()};
					var lvi = new ListViewItem(row);
					lvi.Tag = vehicleList;
					lvDisplay.Items.Add(lvi);
					return;
				}
				//vehicleList = GetAllList();
				//var cars = GetAllList();
				//Vehicle maxB = MaxPrice(vehicleList);				
				//foreach (Vehicle veh in cars)
				//{
				////	var row = new string[] {veh.Make, veh.Model, veh.Mileage.ToString(), veh.Year.ToString(), veh.Price.ToString(),
				////veh.EngineSize, veh.AverageMPG.ToString(), veh.SalesPersonID.ToString()};
				//	var value = new ListViewItem(veh.Make);				
				//	value.SubItems.Add(veh.Model);
				//	value.SubItems.Add(veh.Mileage.ToString("#,###"));
				//	value.SubItems.Add(veh.Year.ToString());
				//	value.SubItems.Add(veh.Price.ToString("c"));
				//	value.SubItems.Add(veh.EngineSize);
				//	value.SubItems.Add(veh.AverageMPG.ToString());
				//	value.SubItems.Add(veh.SalesPersonID.ToString());
				//	value.Tag = cars;
				//	lvDisplay.Items.Add(value);				
				//	return;
				//}
			}
			 catch(Exception ex)
			{
				MessageBox.Show("Error 001: Method - btnMostExpensiveVehicle_Click " + ex.Message);
			}			
		}		

	public IVehicle MaxPrice(List<IVehicle> veh)
		{
			IVehicle max = null;
			decimal minPrice = veh[0].Price;
			foreach (IVehicle c in veh)
			{
				if (c.Price > minPrice)
				{
					minPrice = c.Price;
					c.Make = c.Make;
					c.Model = c.Model;
					c.Mileage = c.Mileage;
					c.Year = c.Year;
					c.Price = c.Price;
					c.EngineSize = c.EngineSize;
					c.AverageMPG = c.AverageMPG;
					c.SalesPersonID = c.SalesPersonID;
					max = c;
				}
			}
			return max;
		}

		private void btnSelectPerson_Click(object sender, EventArgs e)
		{			
			try
			{
				if (cmbSelectPerson.SelectedIndex == 1)
				{
					int i = 101;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 2)
				{
					int i = 102;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 3)
				{
					
					int i = 103;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 4)
				{
					int i = 104;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 5)
				{
					int i = 105;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 6)
				{
					int i = 106;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 7)
				{
					int i = 107;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 8)
				{
					int i = 108;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 9)
				{
					int i = 109;
					GetPersonID(i);
				}
				if (cmbSelectPerson.SelectedIndex == 10)
				{
					int i = 110;
					GetPersonID(i);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error 002: Method - btnSelectPerson_Click" + ex.Message);
			}
		}

		private void btnSelectVehicle_Click(object sender, EventArgs e)
		{
			try
			{				
				if (cmbBoxSelectVehicle.SelectedIndex == 1)
				{
					lvDisplay.Items.Clear();										
					DisplayVehiclesCar();					
				}
				if(cmbBoxSelectVehicle.SelectedIndex == 2)
				{
					lvDisplay.Items.Clear();
					DisplayVehiclesSportCar();
				}
				if(cmbBoxSelectVehicle.SelectedIndex == 3)
				{
					lvDisplay.Items.Clear();
					DisplayVehiclesTruck();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("error 001: " + ex.Message);
			}
		}

		private void btnClearList_Click(object sender, EventArgs e)
		{
			lvDisplay.Items.Clear();
			//// Checks the value of the text.
			//DialogResult result = MessageBox.Show("Do you want to continue working in the program?", 
			//	"6.1 Midterm Project", MessageBoxButtons.YesNo);
			//if (result == DialogResult.No)
			//{
			//	// Initializes the variables to pass to the MessageBox.Show method.
			//	string message = "Close the program?";
			//	string caption = "6.1 Midterm Project";
			//	MessageBoxButtons buttons = MessageBoxButtons.YesNo;
			//	//DialogResult result;
			//	// Displays the MessageBox.
			//	result = MessageBox.Show(this, message, caption, buttons);
			//	if (result == DialogResult.Yes)
			//	{
			//		// Closes the parent form.
			//		this.Close();
			//	}
			//}


			DialogResult result = MessageBox.Show("Would you like Close the program?",
				"6.1 Midterm Project", MessageBoxButtons.YesNo);
			if (result == DialogResult.No)
				lvDisplay.Items.Clear();
			else if (result == DialogResult.Yes)
			{
				Close();
			}
		}
	}
}







//Method - btnSelectVehicle_Click
//int selectedIndex = cmbBoxSelectVehicle.SelectedIndex;
//Object selectedItem = cmbBoxSelectVehicle.SelectedItem;
//cmbBoxSelectVehicle.SelectedIndex = cmbBoxSelectVehicle.Items.IndexOf("Truck");
//lvDisplay.Items.Add("Selected Item " + selectedItem.ToString(), "Index " + (selectedIndex.ToString()));
//string i = cmbBoxSelectVehicle.SelectedItem = "Truck";