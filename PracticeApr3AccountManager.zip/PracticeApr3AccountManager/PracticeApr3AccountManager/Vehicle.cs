﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeApr3AccountManager
{
	public interface IVehicle
	{
		//private string _make;
		//private string _model;
		//private int _mileage;
		//private int _year;
		//private decimal _price;
		//private string _engineSize;
		//private int _averageMPG;
		//private int _salesPersonID;

		//public Vehicle() { }

		//public Vehicle(string make, string model, int mileage, int year, decimal price, 
		//	string engineSize, int averageMPG, int salesPersonID/*, string descriptionZerroToSixty, string descriptionMaxTowing*/)
		//{
		//	_make = make;
		//	_model = model;
		//	_mileage = mileage;
		//	_year = year;
		//	_price = price;
		//	_engineSize = engineSize;
		//	_averageMPG = averageMPG;
		//	_salesPersonID = salesPersonID;
		//}

		string Make { get; set; }  // { _make = value; } }
		string Model { get; set; }  // { _model = value; } }
		int Mileage { get; set; }
		int Year { get; set; }
		decimal Price { get; set; }
		string EngineSize { get; set; }
		int AverageMPG { get; set; }
		int SalesPersonID { get; set; }
		//public string DescriptionZeroToSixty { get { return _descriptionZeroToSixty; } }
		//public string DescriptionMaxTowing { get { return _descriptionMaxTowing; } }

		//public virtual string GetDisplayText(string display) =>
		//	Make + display + Model; + display + Mileage.ToString() + display + Year.ToString() + display + Price.ToString()
		//+ display + EngineSize + display + AverageMPG.ToString() + display + SalesPersonID.ToString();

		//Vehicle MaxPrice(List<Vehicle> veh);

		//{
		//	Vehicle vehicles = new Vehicle();
		//	decimal mixPrice = veh[0].Price;
		//	foreach(Vehicle c in veh)
		//	{				
		//		if (c.Price > mixPrice )
		//		{
		//			mixPrice = c.Price;
		//			vehicles.Make = c.Make;
		//			vehicles.Model = c.Model;
		//			vehicles.Mileage = c.Mileage;
		//			vehicles.Year = c.Year;
		//			vehicles.Price = c.Price;
		//			vehicles.EngineSize = c.EngineSize;
		//			vehicles.AverageMPG = c.AverageMPG;
		//			vehicles.SalesPersonID = c.SalesPersonID;
		//		}								
		//	}
		//	return vehicles;
		//}
	}
}
