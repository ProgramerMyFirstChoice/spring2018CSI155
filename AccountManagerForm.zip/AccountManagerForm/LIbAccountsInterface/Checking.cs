﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIbAccountsInterface
{
    public class Checking : IAccount, ITransaction
    {
        public string AccountType { get; set; } = nameof(Checking);
        public string AccountNumber { get; set; }
        public double Balance { get; set; }
        public double InterestRate { get; set; } = 0;
        public Checking(string accountNumber, double balance)
        {
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public virtual double Deposit(double amount)
        {
            Balance += amount;
            return Balance;
        }

        public virtual double Withdrawal(double amount)
        {
            if (Balance >= amount)
            {
                Balance -= amount;
                return Balance;
            }
            else
            {
                return 0;
            }
        }
        public virtual double ApplyInterestRate(double amount)
        {
            return 0;
        }

    }
}
