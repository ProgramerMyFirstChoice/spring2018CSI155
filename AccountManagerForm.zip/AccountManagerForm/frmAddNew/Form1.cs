﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmAddNew
{
    public partial class Form1 : Form
    {

        Validator val = new Validator();
        List<IAccount> accountList = null;
        public frmAddNew()
        {
            InitializeComponent();
        }
        //form load event to call Load combobox
        private void frmAddNew_Load(object sender, EventArgs e)
        {
            LoadCboAccountType();
        }

        //gets the accountList from Form1
        public void LoadAccountList(List<IAccount> iaccList)
        {
            accountList = iaccList;
        }

        //populates combobox
        public void LoadCboAccountType()
        {
            cboAccountType.Items.Add("Checking");
            cboAccountType.Items.Add("Savings");
            cboAccountType.Items.Add("CD");
            cboAccountType.SelectedIndex = 0;
        }

        //create new account
        private void BtnCreateNew_Click(object sender, EventArgs e)
        {
            try
            {
                if (val.IsPresent(txtAccountNo))
                {
                    if (val.IsPresent(txtAmount) && val.IsDouble(txtAmount))
                    {
                        string accNo = txtAccountNo.Text;
                        double amount = double.Parse(txtAmount.Text);

                        if (cboAccountType.SelectedIndex == 0)
                        {
                            Checking ch = new Checking(accNo, amount);
                            accountList.Add(ch);
                            DisplayConfirmation(ch);
                        }
                        if (cboAccountType.SelectedIndex == 1)
                        {
                            PersonalSavings ps = new PersonalSavings(accNo, amount);
                            accountList.Add(ps);
                            DisplayConfirmation(ps);
                        }
                        if (cboAccountType.SelectedIndex == 2)
                        {
                            CD cd = new CD(accNo, amount, DateTime.Now);
                            accountList.Add(cd);
                            DisplayConfirmation(cd);
                            richTextBox1.AppendText("/nDate Created: " + DateTime.Now);
                        }
                        txtAccountNo.Clear();
                        txtAmount.Clear();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Invalid Input");
            }
        }

        //display confirmation of account creation
        public void DisplayConfirmation(IAccount ia)
        {
            richTextBox1.Text = "Account: " + ia.AccountNumber +
                "\nAccount Type: " + ia.AccountType +
                "\nBalance: " + ia.Balance +
                "\nCreated Successfully!";
        }

        //click event closes form
        private void BtnDone_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.GetNewAccounts(accountList);
            this.Close();
        }
    }
}
