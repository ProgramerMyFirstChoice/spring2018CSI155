﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryVehicleInterface
{
    public class Sportscar:IVehicle
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public int Mileage { get; set; }
        public int SalesPersonID { get; set; }
        public decimal Price { get; set; }
        public string EngineSize { get; set; }
        public int AverageMPG { get; set; }
        
    }
}
