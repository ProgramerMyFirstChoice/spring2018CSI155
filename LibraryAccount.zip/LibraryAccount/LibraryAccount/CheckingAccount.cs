﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAccount
{
    public class CheckingAccount : BankAccount
    {
        public CheckingAccount(string accountNumber, double balance) : base(accountNumber, balance)
        {
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public override string Name
        {
            get
            {
                return "Checking Account"; ;
            }
        }

        public override double ApplyInterest()
        {
            return 0;
        }

        public override double Deposite(double amount)
        {
            base.Balance += amount;
            return base.Balance;
        }

        public override double Withdrawal(double amount)
        {
            if (base.Balance >= amount)
            {
                base.Balance -= amount;
                return base.Balance;
            }
            else
                return 0;
        }
    }
}
