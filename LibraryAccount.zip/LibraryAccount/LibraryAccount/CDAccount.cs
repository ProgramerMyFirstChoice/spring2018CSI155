﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAccount
{
    public class CDAccount: BankAccount
    {

        public CDAccount(string accountNumber, double balance):base(accountNumber,balance)
        {
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public override string Name
        {
            get
            {
                return "CD Account";
            }
        }

        public override double ApplyInterest()
        {
            double maturity = 0;
            maturity = base.Balance + (base.Balance * MaturityTime );
            base.Balance = maturity;

            return 0;
            
        }

        public override double Deposite(double amount)
        {
            base.Balance += amount;
            return base.Balance;
            
        }

        public override double Withdrawal(double amount)
        {
            if (base.Balance >= amount)
            {
                base.Balance -= amount;
                return base.Balance;
            }
            else
                return 0;
        }
        
        public double MaturityTime { get; set; }
    }
}
