﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAccount
{
    // abstract means unchangeable
   public abstract class BankAccount
    {

        public BankAccount(string accountNumber, double balance)
        {
            AccountNumber = accountNumber;
            Balance = balance;
        }
        public string AccountNumber { get; set; }
        public double Balance { get; set; }
        public double InterestRate { get; set; } = .23;
        public abstract double Deposite(double amount);
        public abstract double Withdrawal(double amount);
        public abstract double ApplyInterest();

        public abstract string Name { get; }
       


    }
}
