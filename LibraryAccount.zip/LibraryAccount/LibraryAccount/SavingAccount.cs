﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAccount
{
    public class SavingAccount :BankAccount
    {
        public override string Name
        {
            get
            {
                return "Saving Account";
            }
        }

        public SavingAccount(string accountNumber, double balance):base(accountNumber,balance)
        {
            AccountNumber = accountNumber;
            Balance = balance;
        }
       

        public override double Deposite(double amount)
        {
            base.Balance += amount;
            return base.Balance;

        }

        public override double Withdrawal(double amount)
        {
            if (base.Balance >= amount)
            {
                base.Balance -= amount;
                return base.Balance;
            }
            else
                return 0;
        }
        public override double ApplyInterest()
        {
            double interest = 0;
            interest = base.Balance + (base.Balance * InterestRate);
            base.Balance = interest;

            return 0;

        }
    }
}
