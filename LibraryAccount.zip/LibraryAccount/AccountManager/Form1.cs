﻿
using LibraryAccount;
using System;
using System.Collections.Generic;

using System.Windows.Forms;

namespace AccountManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Validator val = new Validator();

        List<BankAccount> accountlist = new List<BankAccount>();

        #region Checking Click event button
        private void btnNewChecking_Click(object sender, EventArgs e)
        {

        }

        private void btnDepositCheck_Click(object sender, EventArgs e)
        {

        }

        private void btnWithdrawChecking_Click(object sender, EventArgs e)
        {

        }
        #endregion 

        #region Saving Click event button
        private void btnNewSaving_Click(object sender, EventArgs e)
        {

        }

        private void btnDepositSaving_Click(object sender, EventArgs e)
        {

        }

        private void btnWithdrawSaving_Click(object sender, EventArgs e)
        {

        }

        private void btnInterestSaving_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region CD Click event button
        private void btnNewCD_Click(object sender, EventArgs e)
        {

        }

        private void btnDepositCD_Click(object sender, EventArgs e)
        {

        }

        private void btnWithdrawCD_Click(object sender, EventArgs e)
        {

        }

        private void btnMaturityCD_Click(object sender, EventArgs e)
        {

        }
        #endregion


        // Display all accounts
        private void DisplayAccounts()
        {
            listView1.Items.Clear();

            foreach (BankAccount bank in accountlist)
            {
                ListViewItem listItem = new ListViewItem(bank.Name);
                listItem.SubItems.Add(bank.AccountNumber);
                //listItem.SubItems.Add(bank.Name);
                listItem.SubItems.Add(bank.Balance.ToString());

                listView1.Items.Add(listItem);

            }
        }

        // display by account number
        private void DisplayAccountByNumber(BankAccount acctNumber)
        {
            listView1.Items.Clear();

            ListViewItem listView = new ListViewItem(acctNumber.Name);
            listView.SubItems.Add(acctNumber.AccountNumber);
            //listView.SubItems.Add(acctNumber.Name);
            listView.SubItems.Add(acctNumber.Balance.ToString());

            listView1.Items.Add(listView);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CheckingAccount check = new CheckingAccount("ch898989", 8957);
            accountlist.Add(check);


            SavingAccount save = new SavingAccount("s898989", 8957);

            accountlist.Add(save);

            CDAccount cd = new CDAccount("ch898989", 8957);

            accountlist.Add(cd);


            CheckingAccount check2 = new CheckingAccount("ch898989", 8957);
            accountlist.Add(check2);


            SavingAccount save2 = new SavingAccount("ch898989", 8957);

            accountlist.Add(save2);

            CDAccount cd2 = new CDAccount("ch898989", 8957);

            accountlist.Add(cd2);

            DisplayAccounts();


            //indivual checkin 
            //check3.AccountNumber = "";
            //check3.Balance = 23423;

            //accountlist.Add(check3);
        }
    }
}
