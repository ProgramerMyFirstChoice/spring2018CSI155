﻿namespace AccountManager
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDisplayAll = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.AccountType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AccountNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Balance = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCheckingAmount = new System.Windows.Forms.TextBox();
            this.btnDepositCheck = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCheckingNumber = new System.Windows.Forms.TextBox();
            this.btnNewChecking = new System.Windows.Forms.Button();
            this.btnWithdrawChecking = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSavingAmount = new System.Windows.Forms.TextBox();
            this.btnDepositSaving = new System.Windows.Forms.Button();
            this.txtSavingNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNewSaving = new System.Windows.Forms.Button();
            this.btnInterestSaving = new System.Windows.Forms.Button();
            this.btnWithdrawSaving = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtCDAmount = new System.Windows.Forms.TextBox();
            this.btnDepositCD = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCDNumber = new System.Windows.Forms.TextBox();
            this.btnNewCD = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnWithdrawCD = new System.Windows.Forms.Button();
            this.btnMaturityCD = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDisplayAll
            // 
            this.btnDisplayAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayAll.Location = new System.Drawing.Point(348, 651);
            this.btnDisplayAll.Name = "btnDisplayAll";
            this.btnDisplayAll.Size = new System.Drawing.Size(426, 48);
            this.btnDisplayAll.TabIndex = 1;
            this.btnDisplayAll.Text = "Display All";
            this.btnDisplayAll.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.AccountType,
            this.AccountNumber,
            this.Balance});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.Location = new System.Drawing.Point(348, 12);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(426, 628);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // AccountType
            // 
            this.AccountType.Text = "Account Type";
            this.AccountType.Width = 125;
            // 
            // AccountNumber
            // 
            this.AccountNumber.Text = "Account Number";
            this.AccountNumber.Width = 136;
            // 
            // Balance
            // 
            this.Balance.Text = "Balance";
            this.Balance.Width = 152;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCheckingAmount);
            this.groupBox1.Controls.Add(this.btnDepositCheck);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCheckingNumber);
            this.groupBox1.Controls.Add(this.btnNewChecking);
            this.groupBox1.Controls.Add(this.btnWithdrawChecking);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(330, 200);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Checking";
            // 
            // txtCheckingAmount
            // 
            this.txtCheckingAmount.Location = new System.Drawing.Point(94, 48);
            this.txtCheckingAmount.Name = "txtCheckingAmount";
            this.txtCheckingAmount.Size = new System.Drawing.Size(175, 20);
            this.txtCheckingAmount.TabIndex = 2;
            // 
            // btnDepositCheck
            // 
            this.btnDepositCheck.Location = new System.Drawing.Point(94, 103);
            this.btnDepositCheck.Name = "btnDepositCheck";
            this.btnDepositCheck.Size = new System.Drawing.Size(175, 27);
            this.btnDepositCheck.TabIndex = 0;
            this.btnDepositCheck.Text = "Deposit";
            this.btnDepositCheck.UseVisualStyleBackColor = true;
            this.btnDepositCheck.Click += new System.EventHandler(this.btnDepositCheck_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Amount:";
            // 
            // txtCheckingNumber
            // 
            this.txtCheckingNumber.Location = new System.Drawing.Point(94, 19);
            this.txtCheckingNumber.Name = "txtCheckingNumber";
            this.txtCheckingNumber.Size = new System.Drawing.Size(175, 20);
            this.txtCheckingNumber.TabIndex = 2;
            // 
            // btnNewChecking
            // 
            this.btnNewChecking.Location = new System.Drawing.Point(94, 74);
            this.btnNewChecking.Name = "btnNewChecking";
            this.btnNewChecking.Size = new System.Drawing.Size(175, 27);
            this.btnNewChecking.TabIndex = 0;
            this.btnNewChecking.Text = "Save New Checking";
            this.btnNewChecking.UseVisualStyleBackColor = true;
            this.btnNewChecking.Click += new System.EventHandler(this.btnNewChecking_Click);
            // 
            // btnWithdrawChecking
            // 
            this.btnWithdrawChecking.Location = new System.Drawing.Point(94, 132);
            this.btnWithdrawChecking.Name = "btnWithdrawChecking";
            this.btnWithdrawChecking.Size = new System.Drawing.Size(175, 27);
            this.btnWithdrawChecking.TabIndex = 0;
            this.btnWithdrawChecking.Text = "Withdraw";
            this.btnWithdrawChecking.UseVisualStyleBackColor = true;
            this.btnWithdrawChecking.Click += new System.EventHandler(this.btnWithdrawChecking_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Account #";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSavingAmount);
            this.groupBox2.Controls.Add(this.btnDepositSaving);
            this.groupBox2.Controls.Add(this.txtSavingNumber);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnNewSaving);
            this.groupBox2.Controls.Add(this.btnInterestSaving);
            this.groupBox2.Controls.Add(this.btnWithdrawSaving);
            this.groupBox2.Location = new System.Drawing.Point(12, 239);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(330, 200);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Saving";
            // 
            // txtSavingAmount
            // 
            this.txtSavingAmount.Location = new System.Drawing.Point(94, 48);
            this.txtSavingAmount.Name = "txtSavingAmount";
            this.txtSavingAmount.Size = new System.Drawing.Size(175, 20);
            this.txtSavingAmount.TabIndex = 2;
            // 
            // btnDepositSaving
            // 
            this.btnDepositSaving.Location = new System.Drawing.Point(94, 116);
            this.btnDepositSaving.Name = "btnDepositSaving";
            this.btnDepositSaving.Size = new System.Drawing.Size(175, 27);
            this.btnDepositSaving.TabIndex = 0;
            this.btnDepositSaving.Text = "Deposit";
            this.btnDepositSaving.UseVisualStyleBackColor = true;
            this.btnDepositSaving.Click += new System.EventHandler(this.btnDepositSaving_Click);
            // 
            // txtSavingNumber
            // 
            this.txtSavingNumber.Location = new System.Drawing.Point(94, 19);
            this.txtSavingNumber.Name = "txtSavingNumber";
            this.txtSavingNumber.Size = new System.Drawing.Size(175, 20);
            this.txtSavingNumber.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Amount:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Account #";
            // 
            // btnNewSaving
            // 
            this.btnNewSaving.Location = new System.Drawing.Point(94, 87);
            this.btnNewSaving.Name = "btnNewSaving";
            this.btnNewSaving.Size = new System.Drawing.Size(175, 27);
            this.btnNewSaving.TabIndex = 0;
            this.btnNewSaving.Text = "Save New Saving";
            this.btnNewSaving.UseVisualStyleBackColor = true;
            this.btnNewSaving.Click += new System.EventHandler(this.btnNewSaving_Click);
            // 
            // btnInterestSaving
            // 
            this.btnInterestSaving.Location = new System.Drawing.Point(94, 174);
            this.btnInterestSaving.Name = "btnInterestSaving";
            this.btnInterestSaving.Size = new System.Drawing.Size(175, 23);
            this.btnInterestSaving.TabIndex = 0;
            this.btnInterestSaving.Text = "Apply Interest";
            this.btnInterestSaving.UseVisualStyleBackColor = true;
            this.btnInterestSaving.Click += new System.EventHandler(this.btnInterestSaving_Click);
            // 
            // btnWithdrawSaving
            // 
            this.btnWithdrawSaving.Location = new System.Drawing.Point(94, 145);
            this.btnWithdrawSaving.Name = "btnWithdrawSaving";
            this.btnWithdrawSaving.Size = new System.Drawing.Size(175, 27);
            this.btnWithdrawSaving.TabIndex = 0;
            this.btnWithdrawSaving.Text = "Withdraw";
            this.btnWithdrawSaving.UseVisualStyleBackColor = true;
            this.btnWithdrawSaving.Click += new System.EventHandler(this.btnWithdrawSaving_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtCDAmount);
            this.groupBox3.Controls.Add(this.btnDepositCD);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtCDNumber);
            this.groupBox3.Controls.Add(this.btnNewCD);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.btnWithdrawCD);
            this.groupBox3.Controls.Add(this.btnMaturityCD);
            this.groupBox3.Location = new System.Drawing.Point(12, 483);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(330, 200);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "CD";
            // 
            // txtCDAmount
            // 
            this.txtCDAmount.Location = new System.Drawing.Point(94, 55);
            this.txtCDAmount.Name = "txtCDAmount";
            this.txtCDAmount.Size = new System.Drawing.Size(175, 20);
            this.txtCDAmount.TabIndex = 2;
            // 
            // btnDepositCD
            // 
            this.btnDepositCD.Location = new System.Drawing.Point(94, 110);
            this.btnDepositCD.Name = "btnDepositCD";
            this.btnDepositCD.Size = new System.Drawing.Size(175, 27);
            this.btnDepositCD.TabIndex = 0;
            this.btnDepositCD.Text = "Deposit";
            this.btnDepositCD.UseVisualStyleBackColor = true;
            this.btnDepositCD.Click += new System.EventHandler(this.btnDepositCD_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Amount:";
            // 
            // txtCDNumber
            // 
            this.txtCDNumber.Location = new System.Drawing.Point(94, 26);
            this.txtCDNumber.Name = "txtCDNumber";
            this.txtCDNumber.Size = new System.Drawing.Size(175, 20);
            this.txtCDNumber.TabIndex = 2;
            // 
            // btnNewCD
            // 
            this.btnNewCD.Location = new System.Drawing.Point(94, 81);
            this.btnNewCD.Name = "btnNewCD";
            this.btnNewCD.Size = new System.Drawing.Size(175, 27);
            this.btnNewCD.TabIndex = 0;
            this.btnNewCD.Text = "Save New CD";
            this.btnNewCD.UseVisualStyleBackColor = true;
            this.btnNewCD.Click += new System.EventHandler(this.btnNewCD_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Account #";
            // 
            // btnWithdrawCD
            // 
            this.btnWithdrawCD.Location = new System.Drawing.Point(94, 139);
            this.btnWithdrawCD.Name = "btnWithdrawCD";
            this.btnWithdrawCD.Size = new System.Drawing.Size(175, 27);
            this.btnWithdrawCD.TabIndex = 0;
            this.btnWithdrawCD.Text = "Withdraw";
            this.btnWithdrawCD.UseVisualStyleBackColor = true;
            this.btnWithdrawCD.Click += new System.EventHandler(this.btnWithdrawCD_Click);
            // 
            // btnMaturityCD
            // 
            this.btnMaturityCD.Location = new System.Drawing.Point(94, 168);
            this.btnMaturityCD.Name = "btnMaturityCD";
            this.btnMaturityCD.Size = new System.Drawing.Size(175, 23);
            this.btnMaturityCD.TabIndex = 0;
            this.btnMaturityCD.Text = "Apply Maturity";
            this.btnMaturityCD.UseVisualStyleBackColor = true;
            this.btnMaturityCD.Click += new System.EventHandler(this.btnMaturityCD_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 715);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btnDisplayAll);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnDisplayAll;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader AccountType;
        private System.Windows.Forms.ColumnHeader AccountNumber;
        private System.Windows.Forms.ColumnHeader Balance;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCheckingAmount;
        private System.Windows.Forms.Button btnDepositCheck;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCheckingNumber;
        private System.Windows.Forms.Button btnNewChecking;
        private System.Windows.Forms.Button btnWithdrawChecking;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSavingAmount;
        private System.Windows.Forms.Button btnDepositSaving;
        private System.Windows.Forms.TextBox txtSavingNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNewSaving;
        private System.Windows.Forms.Button btnInterestSaving;
        private System.Windows.Forms.Button btnWithdrawSaving;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtCDAmount;
        private System.Windows.Forms.Button btnDepositCD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCDNumber;
        private System.Windows.Forms.Button btnNewCD;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnWithdrawCD;
        private System.Windows.Forms.Button btnMaturityCD;
    }
}

