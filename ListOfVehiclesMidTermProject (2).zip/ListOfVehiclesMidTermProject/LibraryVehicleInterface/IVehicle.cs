﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryVehicleInterface
{
    public interface IVehicle
    {
        string Make { get; set; }
        string Model { get; set; }
        int Mileage { get; set; }
        int SalesPersonID { get; set; }
        decimal Price { get; set; }
        string EngineSize { get; set; }
        int AverageMPG { get; set; }
        
    }
}
