﻿
using LibraryVehicleInterface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListOfVehiclesMidTermProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //create list of accounts
        List<IVehicle> ivehicleList = new List<IVehicle>();
        //instantiate validator class
        Validator val = new Validator();

        #region Helper
        //// Method that takes a customer id and
        //// return the customer object or null if not found
        public IVehicle GetVehiclebySalespersonID(int id)
        {
            foreach (IVehicle salePerID in ivehicleList)
            {
                if (salePerID.SalesPersonID == id)
                {
                    return salePerID;
                }
            }
            return null;
        }

        //// Method that takes a account number and
        //// return the account object or null if not found
        //public Account GetCustomerByAcctNumber(int accountNumber)
        //{
        //    foreach (Account acctNumber in accountList)
        //    {
        //        if (acctNumber.AccountNumber == accountNumber)
        //        {
        //            return acctNumber;
        //        }
        //    }
        //    return null;
        //}


        //// Method to clear textboxes
        //public void ClearTextboxes()
        //{
        //    txtAccountNum.Clear();
        //    txtBalance.Clear();

        //}

        //// Method to populate a Add New Customer customerID combobox
        //public void PopulatecboCustomerID()
        //{
        //    foreach (Customer customer in customerList)
        //    {
        //        cboCustomerIDAdd.Items.Add(customer.ID);
        //        cboCustomerIDRemove.Items.Add(customer.ID);
        //    }


        //}

        //// Method to populate a Add New Customer customerID combobox
        //public void PopulatecboAccountNumber()
        //{
        //    foreach (Account acctNumber in accountList)
        //    {
        //        cboAccountNumber.Items.Add(acctNumber.AccountNumber);

        //    }
        //}
        //// Method that take list as input and find the highest account balance
        //// return the customer high object 
        //public Customer HighsetAccount(List<Customer> custList)
        //{
        //    // create an object to hold customer high
        //    Customer customerHigh = new Customer();
        //    // create an object to hold account low
        //    Account accountHigh = new Account();

        //    foreach (Customer custHigh in custList)
        //    {
        //        foreach (Account acctHigh in custHigh.accountList)
        //        {
        //            if (acctHigh.Balance > highestBalance)
        //            {
        //                // if the Balance higher than the preassign highest value of a variable
        //                // assign it to the highest variable
        //                highestBalance = acctHigh.Balance;
        //                customerHigh = GetCustomerByID(custHigh.ID);
        //                accountHigh = customerHigh.GetAccount(acctHigh.AccountNumber);
        //            }

        //        }
        //    }
        //    // add the return object to customerHigh object
        //    customerHigh.AddNewAccount(accountHigh);

        //    // return customer high object that has highest balance
        //    return customerHigh;

        //}
        //// Button event max display the highest balance from the account
        //private void btnMax_Click(object sender, EventArgs e)
        //{
        //    Customer highBalance = HighsetAccount(customerList);
        //    richTextBox1.Clear();

        //    richTextBox1.AppendText(highBalance.FirstName + " " + highBalance.LastName +
        //         " " + " Highest Balance: " + highestBalance.ToString("c"));


        //}

        //// Method that takes a customer id and
        //// return the customer object or null if not found
        //public Customer GetCustomerByID(int id)
        //{
        //    foreach (Customer customerID in customerList)
        //    {
        //        if (customerID.ID == id)
        //        {
        //            return customerID;
        //        }
        //    }
        //    return null;
        //}
        ////get the account by the account number
        //private IAccount GetAccountByNumber(string AccountNumber)
        //{
        //    foreach (IAccount num in iaccList)
        //    {
        //        if (num.AccountNumber == AccountNumber)
        //            return num;
        //    }
        //    return
        // }

        ////load the comboboxes with the account types
        //public void LoadCboAccountType()
        //{
        //    cboAccountType.Items.Add("Checking");
        //    cboAccountType.Items.Add("Savings");
        //    cboAccountType.Items.Add("CD");
        //    cboAccountType.SelectedIndex = 0;
        //}



        //public void DisplayAccounts()
        //{
        //    listView1.Items.Clear();
        //    foreach (IAccount a in iaccList)
        //    {
        //        ListViewItem lstitem = new ListViewItem(a.AccountType);
        //        lstitem.SubItems.Add(a.AccountNumber);
        //        lstitem.SubItems.Add(a.Balance.ToString("c"));
        //        lstitem.SubItems.Add(a.InterestRate.ToString("c"));
        //        listView1.Items.Add(lstitem);
        //    }
        //}

        #endregion

        
    }
}
