﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntroductionToPolymorphism
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// Method that takes a single parameter object of type Circle and displays

        /// its data

        ///

        private void Display(Circle circle)

        {
            //clear the listview before displaying the next row

            //so only one row is displayed

            listView1.Items.Clear();

            //get a populate ListViewItem object

            ListViewItem row = GetPopulatedListViewItem(circle);

            //add the row to the listview1

            listView1.Items.Add(row);

            

        }





        ///method that create a ListViewItem, populates with a Circle object data

        ///and returns it

        ///

        private ListViewItem GetPopulatedListViewItem(Circle circle)

        {
            ListViewItem lstviewitem;



            if (circle is Sphere)

            {

                //cast circle object to its real type Sphere

                Sphere sphere = (Sphere)circle;

                //get the name of circle object type

                string typename = sphere.GetType().Name;

                //get the radius of the sphere object

                double radius = sphere.Radius;

                //get its area

                double area = sphere.Area();

                //get its volume

                double volume = sphere.Volume();



                lstviewitem = new ListViewItem(typename);

                lstviewitem.SubItems.Add(radius.ToString("f"));

                lstviewitem.SubItems.Add(area.ToString("f"));

                lstviewitem.SubItems.Add(volume.ToString("f"));

            }

            else //it must a Circle--no casting is necessary

            {

                //get the name of circle object type

                string typename = circle.GetType().Name;

                //get the radius of the circle object

                double radius = circle.Radius;

                //get its area

                double area = circle.Area();

                //get its volume

                double volume = circle.Volume();



                lstviewitem = new ListViewItem(typename);

                lstviewitem.SubItems.Add(radius.ToString("f"));

                lstviewitem.SubItems.Add(area.ToString("f"));

                lstviewitem.SubItems.Add(volume.ToString("f"));

            }

            return lstviewitem;




            ////get the name of circle object type

            //string typename = circle.GetType().Name;

            ////get the radius of the circle object

            //double radius = circle.Radius;

            ////get its area

            //double area = circle.Area();

            ////get its volume

            //double volume = circle.Volume();



            //ListViewItem lstviewitem = new ListViewItem(typename);

            //lstviewitem.SubItems.Add(radius.ToString("f"));

            //lstviewitem.SubItems.Add(area.ToString("f"));

            //lstviewitem.SubItems.Add(volume.ToString("f"));

            //return lstviewitem;

        }
        private void btnCreateRandomCircle_Click(object sender, EventArgs e)
        {
            Random rand = new Random(DateTime.Now.Millisecond);

            //get a random radius of type double between 1 and 100

            double radius = 1 + rand.NextDouble() * 100;



            //create a Circle object

            Circle circle = new Circle(radius);

            //display its data

            Display(circle);
        }

        private void btnCreateRandomSphere_Click(object sender, EventArgs e)
        {
            Random rand = new Random(DateTime.Now.Millisecond);

            //get a random radius of type double between 1 and 100

            double radius = 1 + rand.NextDouble() * 100;



            //create a Sphere object

            Sphere sphere = new Sphere(radius);

            //display its data

            Display(sphere);
        }

        private void btnClearDisplay_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }
    }
}
