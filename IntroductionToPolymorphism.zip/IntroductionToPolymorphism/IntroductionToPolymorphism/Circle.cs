﻿using System;



namespace IntroductionToPolymorphism
{
    class Circle
    {
        #region original code
        //private double _radius;

        ////Constructor

        //public Circle(double radius)

        //{

        //    _radius = radius;
        //    //add trace statement
        //    Trace.WriteLine("Circle constructor is running");
        //}

        //public double Radius

        //{

        //    get { return this._radius; }

        //}



        //public double Area()

        //{

        //    System.Diagnostics.Trace.WriteLine("Circle area() method is running");

        //    return Math.PI * _radius * _radius;

        //}

        //public double Volume()

        //{

        //    System.Diagnostics.Trace.WriteLine("Circle volume() method is running");

        //    return 0;

        //}
        #endregion


        private double _radius;



        public Circle(double radius)

        {

            System.Diagnostics.Trace.WriteLine("\nCircle constructor is running");

            this._radius = radius;

        }

        public double Radius

        {

            get { return this._radius; }

        }



        public virtual double Area()

        {

            System.Diagnostics.Trace.WriteLine("Circel area() method is running");

            return Math.PI * _radius * _radius;

        }

        public virtual double volume()

        {

            System.Diagnostics.Trace.WriteLine("Circle volume() method is running");

            return 0;

        }

    }
}

