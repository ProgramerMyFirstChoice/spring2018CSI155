﻿using System;


namespace IntroductionToPolymorphism
{
    class Sphere:Circle
    {
        #region original code
        //public Sphere(double radius) : base(radius)

        //{

        //    //add trace statement

        //    System.Diagnostics.Trace.WriteLine("Sphere constructor is running");

        //}

        ////hide method area()

        //new public double Area()

        //{

        //    System.Diagnostics.Trace.WriteLine("Sphere area() method is running");

        //    return 4 * Math.PI * Radius * Radius;

        //}

        ////hide method volume

        //new public double Volume()

        //{

        //    System.Diagnostics.Trace.WriteLine("Sphere volume() method is running");

        //    return 4 * Math.PI * Math.Pow(Radius, 3) / 3;

        //}
        #endregion

        public Sphere(double radius) : base(radius)

        {

            //field _radius is define in Circle as

            // private, it cannot be accessed

            // by Sphere, so the Sphere constructor is calling

            // the Circle constructor and passes

            // it the radius parameter

            //add trace statement

            System.Diagnostics.Trace.WriteLine("Sphere constructor is running");

        }

        //overridemethod area()

        public override double Area()

        {

            System.Diagnostics.Trace.WriteLine("Sphere area() method is running");

            return 4 * Math.PI * Radius * Radius;

        }



        //override method volume

        public override double Volume()

        {

            System.Diagnostics.Trace.WriteLine("Sphere volume() method is running");

            return 4 * Math.PI * Math.Pow(Radius, 3) / 3;

        }
    }
}

