﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Containment_Example_1
{
    /* Nahom Gebreyohannies
     * 
     * Code For Week 1.1 Object Containment
     * Course CSI 155
     * 
     * Instructor Christy Hernadez
     */ 

    public partial class Form1 : Form
    {
        Random rand = new Random();
        //create a list of customers
        List<Customer> customerList = new List<Customer>();
        List<Account> accountList = new List<Account>();
        //instantiate Validator
        Validator val = new Validator();
        //instantiate Customer
        Customer cuctomerInfo = new Customer();
        //instantiate Account
        Account accountInfo = new Account();

        // Global variable to be used in calculation of
        // calculation of the highest and lowest balance of the account
        decimal highestBalance = decimal.MinValue;
        decimal lowestBalance = decimal.MaxValue;

        public Form1()
        {

            InitializeComponent();

            //load with premade Customerlist on form load
            PreLoadsCustomerList();
            // Loaded the Account type combobox on form load
            PopulatecboActype();

            // Loaded the Customer ID for customer combobox on form load
            PopulatecboCustomerID();
            PopulatecboAccountNumber();
        }
        // Method that preloads the customerList and AccountList with
        //  customers and account informaton
        private void PreLoadsCustomerList()
        {
            Customer customer1 = new Customer("Andy", "Adams", 1234);
            //add few accounts to this customer
            Account saving = new Account(1230, 3300, AccountType.savings,
                                       new DateTime(2017, 2, 12));
            Account checking = new Account(1434, 9900, AccountType.checking,
                                       new DateTime(2015, 9, 1));
            //add this account to the customer
            customer1.AddNewAccount(saving);
            customer1.AddNewAccount(checking);
            customerList.Add(customer1);
            accountList.Add(saving);
            accountList.Add(checking);

            //----------------------------------------------------------
            Customer customer2 = new Customer("Beth", "Bartos", 1235);
            //add few accounts to this customer
            saving = new Account(1554, 1299, AccountType.savings,
                                       new DateTime(2016, 1, 31));
            checking = new Account(1466, 3389, AccountType.checking,
                                       new DateTime(2014, 12, 1));
            //add this account to the customer
            customer2.AddNewAccount(saving);
            customer2.AddNewAccount(checking);
            customerList.Add(customer2);

            //----------------------------------------------------------
            Customer customer3 = new Customer("Chelsea", "Caday", 1236);
            //add few accounts to this customer
            saving = new Account(2554, 2998, AccountType.savings,
                                       new DateTime(2011, 7, 7));
            checking = new Account(2466, 3399, AccountType.checking,
                                       new DateTime(2015, 6, 8));
            //add this account to the customer
            customer3.AddNewAccount(saving);
            customer3.AddNewAccount(checking);
            customerList.Add(customer3);
            accountList.Add(saving);
            accountList.Add(checking);
            //----------------------------------------------------------
            Customer customer4 = new Customer("Gary", "Jordan", 1237);
            //add few accounts to this customer
            saving = new Account(3554, 1298, AccountType.savings,
                                       new DateTime(2015, 9, 6));
            checking = new Account(3466, 3899, AccountType.checking,
                                       new DateTime(2015, 4, 2));
            //add this account to the customer
            customer4.AddNewAccount(saving);
            customer4.AddNewAccount(checking);
            customerList.Add(customer4);
            accountList.Add(saving);
            accountList.Add(checking);

            // Call clear method and display method
            ClearTextboxes();
            DisplayCustomers();

        }

        // Button click event to add new account to existing customers
        private void BtnAddAccount_Click(object sender, EventArgs e)
        {
            if (cboCustomerIDAdd.Text != "")
            {
                if (val.IsPresent(txtAccountNum) && val.IsInt32(txtAccountNum))
                {
                    if (val.IsPresent(txtBalance) && val.IsDecimal(txtBalance))
                    {
                        // Get account number from customer
                        accountInfo.AccountNumber = int.Parse(txtAccountNum.Text);

                        // Get balance amount from customer
                        accountInfo.Balance = decimal.Parse(txtBalance.Text);

                        // Assign the selected combobox Account type to string variable
                        string type = cboAccountType.SelectedItem.ToString();

                        // assign Account type to Account Type property using Enum
                        accountInfo.Type = (AccountType)Enum.Parse(typeof(AccountType), type);

                        // Create an account
                        Account account = new Account(accountInfo.AccountNumber, accountInfo.Balance, accountInfo.Type, DateTime.Now);

                        // Assign the selected combobox Customer ID to string variable
                        string idString = cboCustomerIDAdd.SelectedItem.ToString();
                        int idInt = 0;

                        // Change the value from string to int and assign it to variable
                        int.TryParse(idString, out idInt);

                        // Call GetCustomerByID method to compare the user selection
                        // return customer object
                        Customer customer = GetCustomerByID(idInt);

                        if (customer != null)
                        {
                            // Add account to this customer
                            customer.AddNewAccount(account);
                            // Clear
                            ClearTextboxes();
                            // Display to richbox
                            DisplayCustomers();
                        }
                        else
                        {
                            // Error
                            MessageBox.Show("Invalide id");
                        }

                    }
                }
            }
            else
            {
                // Error
                MessageBox.Show("Select id from the list");
            }

        }

        // Button display
        private void BtnDisplay(object sender, EventArgs e)
        {
            // Call the display method
            DisplayCustomers();
        }

        // Close account, specified by account number,
        // of the specified cusstomer: by id
        // cal GetCustomerByID() method
        private void BtnCloseAccount(object sender, EventArgs e)
        {          
            if (cboCustomerIDRemove.Text != "")
            {
                // Assign the selected combobox Customer ID to string variable
                string idString = cboCustomerIDRemove.SelectedItem.ToString();
                int idInt = 0;

                // Change the string to int
                int.TryParse(idString, out idInt);

                // Call GetCustomerByID method to compare the user selection
                // return customer object
                Customer customer = GetCustomerByID(idInt);

                if (customer != null)
                {

                    if (cboAccountNumber.Text != "")
                    {
                        string acctNumString = cboAccountNumber.SelectedItem.ToString();
                        int acctNumInt = 0;

                        int.TryParse(acctNumString, out acctNumInt);

                        Account account = GetCustomerByAcctNumber(acctNumInt);

                        if (account != null)
                        {
                            decimal amount = customer.CloseAccount(acctNumInt);

                            MessageBox.Show("Cash Back: " + amount.ToString("c"));

                            ClearTextboxes();
                            DisplayCustomers();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Select Account number from the list");
                    }
                }

            }
            else
            {

                MessageBox.Show("Select id from the list");

            }
        }

        // Method that takes a customer id and
        // return the customer object or null if not found
        public Customer GetCustomerByID(int id)
        {
            foreach (Customer customerID in customerList)
            {
                if (customerID.ID == id)
                {
                    return customerID;
                }
            }
            return null;
        }

        // Method that takes a account number and
        // return the account object or null if not found
        public Account GetCustomerByAcctNumber(int accountNumber)
        {
            foreach (Account acctNumber in accountList)
            {
                if (acctNumber.AccountNumber == accountNumber)
                {
                    return acctNumber;
                }
            }
            return null;
        }

        //method to display customers
        public void DisplayCustomers()
        {
            richTextBox1.Clear();
            // Sequence thru the customerList
            foreach (Customer customer in customerList)
            {
                // display the customer info
                richTextBox1.AppendText(customer.FirstName + " " +
                                        customer.LastName + " " +
                                        customer.ID + "\n");

                // Sequence thru this customer accounts
                foreach (Account account in customer.Accounts)
                {
                    richTextBox1.AppendText(
                        account.AccountNumber + " " +
                        account.Balance.ToString("c") + " " +
                        account.Type + " " +
                        account.DateCreated.ToShortDateString() + "\n");
                }

                richTextBox1.AppendText("\n'");
            }

        }

        // Method to display all customer and their account information
        private void PreloadToRichbox()
        {
            foreach (Customer cust in customerList)
            {
                richTextBox1.AppendText(cust.FirstName + "  " + cust.LastName + "   " + cust.ID + "  " + "\n\n");
                foreach (Account acct in cust.Accounts)
                {
                    richTextBox1.AppendText(acct.AccountNumber.ToString() + "  "
                        + acct.Balance.ToString() + acct.Type + "  "
                        + acct.DateCreated.ToShortDateString() + "\n");

                    richTextBox1.AppendText("\n\n");
                }
            }
        }

        // Method to clear textboxes
        public void ClearTextboxes()
        {
            txtAccountNum.Clear();
            txtBalance.Clear();
            
        }

        // Method to populate Closing Account customerID combobox
        public void PopulatecboActype()
        {
            foreach (AccountType item in Enum.GetValues(typeof(AccountType)))
            {
                cboAccountType.Items.Add(item);
            }

            cboAccountType.SelectedIndex = 0;
        }

        // Method to populate a Add New Customer customerID combobox
        public void PopulatecboCustomerID()
        {
            foreach (Customer customer in customerList)
            {
                cboCustomerIDAdd.Items.Add(customer.ID);
                cboCustomerIDRemove.Items.Add(customer.ID);
            }

           
        }

        // Method to populate a Add New Customer customerID combobox
        public void PopulatecboAccountNumber()
        {
            foreach (Account acctNumber in accountList)
            {
                cboAccountNumber.Items.Add(acctNumber.AccountNumber);

            }
        }

        // Button event min display the lowest balance from the account
        private void btnMin_Click(object sender, EventArgs e)
        {
            Customer lowBal = LowestAccount(customerList);
            richTextBox1.Clear();

            richTextBox1.AppendText(lowBal.FirstName + " " + lowBal.LastName +
                 " " + " Lowest Balance: " + lowestBalance.ToString("c"));
        }

        // Button event max display the highest balance from the account
        private void btnMax_Click(object sender, EventArgs e)
        {
            Customer highBalance = HighsetAccount(customerList);
            richTextBox1.Clear();

            richTextBox1.AppendText(highBalance.FirstName + " " + highBalance.LastName +
                 " " + " Highest Balance: " + highestBalance.ToString("c"));


        }

        // Method that take list as input and find the lowest account balance
        // return the customer low object 
        public Customer LowestAccount(List<Customer> custList)
        {
            // create an object to hold customer low
            Customer customerLow = new Customer();

            // Create an object to hold account low
            Account accountLow = new Account();

            // Loop thru the list and find the lowest balancefrom the list
            foreach (Customer custL in custList)
            {
                foreach (Account acctLow in custL.accountList)
                {
                    if (acctLow.Balance < lowestBalance)
                    {
                        // if the Balance lower than the preassign lower value of a variable
                        // assign it to the lowestBalance variable
                        lowestBalance = acctLow.Balance;

                        customerLow = GetCustomerByID(custL.ID);
                        // return account low object
                        accountLow = customerLow.GetAccount(acctLow.AccountNumber);
                    }

                }
            }

            // add the return object to customerLow object
            customerLow.AddNewAccount(accountLow);

            // return customer low object that has lowest balance
            return customerLow;

        }

        // Method that take list as input and find the highest account balance
        // return the customer high object 
        public Customer HighsetAccount(List<Customer> custList)
        {
            // create an object to hold customer high
            Customer customerHigh = new Customer();
            // create an object to hold account low
            Account accountHigh = new Account();

            foreach (Customer custHigh in custList)
            {
                foreach (Account acctHigh in custHigh.accountList)
                {
                    if (acctHigh.Balance > highestBalance)
                    {
                        // if the Balance higher than the preassign highest value of a variable
                        // assign it to the highest variable
                        highestBalance = acctHigh.Balance;
                        customerHigh = GetCustomerByID(custHigh.ID);
                        accountHigh = customerHigh.GetAccount(acctHigh.AccountNumber);
                    }

                }
            }
            // add the return object to customerHigh object
            customerHigh.AddNewAccount(accountHigh);

            // return customer high object that has highest balance
            return customerHigh;     

        }

    }

    #region Customer Account and Validator class AccountType Enum 
    // Customer class
    public class Customer
    {
        //properties
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int ID { get; set; }

        public List<Account> accountList; //containment by composition
        //copy the list of accounts to an array of accounts
        public Account[] Accounts { get { Account[] accounts = accountList.ToArray(); return accounts; } }

        //constructor
        public Customer(string firstname, string lastname, int id)
        {
            FirstName = firstname;
            LastName = lastname;
            ID = id;
            accountList = new List<Account>();
        }
        // Defualt constructor
        public Customer() { }

        public void AddNewAccount(Account account)
        {
            //you may do any checking to make sure that the 
            //account has all the valid data...
            if (!String.IsNullOrEmpty(FirstName) && !String.IsNullOrEmpty(LastName))
            {
                //adds the account to the accountList
                accountList.Add(account);
            }
        }
        public decimal CloseAccount(int accountNumber)
        {
            //code to add call the GeAccount to get the Account object
            Account account = GetAccount(accountNumber);
            //make sure that it is not null
            if (account != null)
            {
                //remove it from the accountList
                accountList.Remove(account);
                return account.Balance;
            }
            return 0;
        }
       // Method to get accountNumber number as input 
       // and display account object
        public Account GetAccount(int accountNumber)
        {
            //search thru the accountList and return the 
            //Account object with the given accountNumber
            //or null if not found
            foreach (Account account in accountList)
            {
                if (account.AccountNumber == accountNumber)
                    return account;
            }
            return null;
        }
    }

    // creating enum for account type 
    public enum AccountType { checking, savings, cd }

    // Account Class
    public class Account
    {
        //properties
        public int AccountNumber { get; set; }
        public decimal Balance { get; set; }
        public AccountType Type { get; set; }
        public DateTime DateCreated { get; set; }

        // Parameterized constructor
        public Account(int accountNumber, decimal balance, AccountType type, DateTime dateCreated)
        {
            AccountNumber = accountNumber;
            Balance = balance;
            Type = type;
            DateCreated = dateCreated;
        }

        // defualt constructor
        public Account() { }

        // Method to withdraw amount from account balance
        public bool WithDraw(decimal amount)
        {
            
            if (Balance > amount)
            {
                Balance -= amount;
                return true;
            }
            return false;
        }

        // Method to deposit an amount to account balance
        public void Deposit(decimal amount)
        {
            //To Do for later: complete code
            Balance += amount;
        }
    }
   
    // Validator class
    class Validator
    {
        // Fields
        private string title = "Entry Error";

        // Title property
        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }

        // Method for presence of value in textbox
        public bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(textBox.Tag + " is a required field.", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }

        // Method that check whether the user input is double
        public bool IsDouble(TextBox textBox)
        {
            if (Double.TryParse(textBox.Text, out double number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a number or decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }

        // Method that check whether the user input is decimal
        public bool IsDecimal(TextBox textBox)
        {
            if (Decimal.TryParse(textBox.Text, out decimal number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }

        // Method that check whether the user input is integer
        public bool IsInt32(TextBox textBox)
        {
            if (Int32.TryParse(textBox.Text, out int number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be an integer.", Title);
                textBox.Focus();
                return false;
            }
        }

        // Method that check whether the user input is with specified value
        public bool IsWithinRange(TextBox textBox, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number <= min || number > max)
            {
                MessageBox.Show(textBox.Tag + " must be greater than " + min + " and less than " + max + ".", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }
    }
    #endregion

}



