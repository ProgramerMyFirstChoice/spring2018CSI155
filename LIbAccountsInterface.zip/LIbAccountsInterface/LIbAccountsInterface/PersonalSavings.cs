﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LIbAccountsInterface
{
    public class PersonalSavings
        : Savings,IAccount, ITransaction
    {
        new public string AccountType { get; set; } 
            = nameof(PersonalSavings);
       
        public PersonalSavings(string accountNumber, double balance)
        :base(accountNumber, balance)
        {
        }

        public override double Deposit(double amount)
        {
            Balance += amount;
            return Balance;
        }

        public override double Withdrawal(double amount)
        {
            if (Balance >= amount)
            {
                Balance -= amount;
                return Balance;
            }
            else
            {
                return 0;
            }
        }
       

    }
}
