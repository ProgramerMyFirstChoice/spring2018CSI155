﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIbAccountsInterface
{
    public abstract class Savings: IAccount,ITransaction
    {
        public string AccountType { get; set; } = nameof(Savings);
        public string AccountNumber { get; set; }
        public double Balance { get; set; }
        public double InterestRate { get; set; } = .11;

        public Savings(string accountNumber, double balance)       
        {
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public virtual double Deposit(double amount)
        {
            Balance += amount;
            return Balance;
        }

        public virtual double Withdrawal(double amount)
        {
            if (Balance >= amount)
            {
                Balance -= amount;
                return Balance;
            }
            else
            {
                return 0;
            }
        }
        public virtual double ApplyInterestRate(double amount)
        {
            double interest = 0;
            interest = amount * InterestRate;
            return interest;
           
        }
    }
}
