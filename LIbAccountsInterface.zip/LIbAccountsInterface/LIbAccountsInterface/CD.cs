﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIbAccountsInterface
{
    public class CD:Savings,IAccount,ITransaction
    {
        new public string AccountType { get; set; }
           = nameof(CD);
        public static DateTime DepositDate { get; set; }
        new public double InterestRate { get; set; } = .12;
        public static double WithdrawPenalty { get; set; }
        new public static double Balance { get; set; }
        public CD(string accountNumber, double balance, DateTime depositDate)
        : base(accountNumber, balance)
        {
            DepositDate = depositDate;
        }
        public override double Deposit(double amount)
        {
            Balance += amount;
            return Balance;
        }

        public static double Withdrawal
            (double amount, double penalty)
        {
            WithdrawPenalty = (Balance * penalty);
            Balance -= amount + WithdrawPenalty;
            return Balance;
        }
       

    }
}
