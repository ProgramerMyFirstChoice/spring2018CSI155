﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIbAccountsInterface
{
    public interface IAccount : ITransaction
    {
        string AccountType { get; set; }
        string AccountNumber { get; set; }
        double Balance { get; set; }
        double InterestRate { get; set; }
      
    }
}
