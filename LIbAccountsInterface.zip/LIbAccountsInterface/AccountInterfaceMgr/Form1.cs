﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LIbAccountsInterface;

namespace AccountInterfaceMgr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //create list of accounts
        List<IAccount> iaccList = new List<IAccount>();
        //instantiate validator class
        Validator val = new Validator();
        //global date time instantiation
        DateTime dt = new DateTime();

        //click event opens new form
        private void BtnAddNew_Click(object sender, EventArgs e)
        {
            frmAddNew addForm = new frmAddNew();
            addForm.LoadAccountList(iaccList);
            addForm.Show();

        }

        #region Transactions
        //click event for deposit
        private void BtnDeposit_Click(object sender, EventArgs e)
        {
            if(val.IsPresent(txtAmount) && val.IsDouble(txtAmount))
            {
                double amount = double.Parse(txtAmount.Text);
                IAccount iaOne = GetAccountByNumber(txtAccountNo.Text);
                iaOne.Balance = iaOne.Deposit(amount);

                if (cboAccountType.SelectedIndex == 2 || 
                    cboAccountType.SelectedIndex == 1)
                {
                    iaOne.InterestRate = iaOne.ApplyInterestRate(amount);
                }                             
                txtBalance.Text = iaOne.Balance.ToString();
                DisplayAccounts();
            }

        }
        //clcik event for withdrawal
        private void BtnWithdrawal_Click(object sender, EventArgs e)
        {
            if (val.IsPresent(txtAmount) && val.IsDouble(txtAmount))
            {
                double amount = double.Parse(txtAmount.Text);
                IAccount iaOne = GetAccountByNumber(txtAccountNo.Text);

                if (cboAccountType.SelectedIndex == 2)
                {
                    if(CD.DepositDate.Year >= CD.DepositDate.Year + 5)
                    {
                        double penalty = .02;
                        iaOne.Balance =CD.Withdrawal(amount, penalty);
                    }
                    else
                    {
                        double penalty = .05;
                        iaOne.Balance = CD.Withdrawal(amount, penalty);
                    }                                     
                    txtBalance.Text = iaOne.Balance.ToString();
                }
                else
                {                 
                    iaOne.Balance = iaOne.Withdrawal(amount);
                    txtBalance.Text = iaOne.Balance.ToString();
                }
                DisplayAccounts();
            }
        }
        #endregion

        #region Helper Methods
        //get the accountlist after a new account is added
        public void GetNewAccounts(List<IAccount> accList)
        {
            if (accList != null)
            {
                iaccList = accList;
                listView1.Items.Clear();
            }

        }
        //get the account by the account number
        private IAccount GetAccountByNumber(string AccountNumber)
        {
            foreach (IAccount num in iaccList)
            {
                if (num.AccountNumber == AccountNumber)
                    return num;
            }
            return null;
        }
        //when listview item is selected the textboxes are populated
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                int index = listView1.SelectedIndices[0];
                IAccount ia = iaccList[index];
                if (ia.AccountType == "PersonalSavings")
                {
                    cboAccountType.SelectedIndex = 1;
                }
                if (ia.AccountType == "CD")
                {
                    cboAccountType.SelectedIndex = 2;

                }
                txtAccountNo.Text = ia.AccountNumber;
                txtBalance.Text = ia.Balance.ToString();
            }
        }
        //load the comboboxes with the account types
        public void LoadCboAccountType()
        {
            cboAccountType.Items.Add("Checking");
            cboAccountType.Items.Add("Savings");
            cboAccountType.Items.Add("CD");
            cboAccountType.SelectedIndex = 0;
        }
        #endregion

        #region Display
        //refresh listview after adding the new account(s)
        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            DisplayAccounts();
        }
        //form load event to create accounts and load combobox with account types
        private void Form1_Load(object sender, EventArgs e)
        {
            Checking cha = new Checking("C234646", 1000.00);
            iaccList.Add(cha);
            cha = new Checking("C797665", 500.00);
            iaccList.Add(cha);
            PersonalSavings sav = new PersonalSavings("S3466", 8000.00);
            iaccList.Add(sav);
            sav = new PersonalSavings("S6345", 90000.00);
            iaccList.Add(sav);
            dt = new DateTime(1999, 5, 1);
            CD cd = new CD("CD258", 60000.00, dt);
            iaccList.Add(cd);
            dt = new DateTime(2009, 7, 15);
            cd = new CD("CD741", 30000.00, dt);
            iaccList.Add(cd);
            DisplayAccounts();
            LoadCboAccountType();
        }
        //Displays List<IAccount> to the listview
        public void DisplayAccounts()
        {
            listView1.Items.Clear();
            foreach (IAccount a in iaccList)
            {
                ListViewItem lstitem = new ListViewItem(a.AccountType);
                lstitem.SubItems.Add(a.AccountNumber);
                lstitem.SubItems.Add(a.Balance.ToString("c"));
                lstitem.SubItems.Add(a.InterestRate.ToString("c"));
                listView1.Items.Add(lstitem);
            }
        }
        #endregion

       
    }
}
