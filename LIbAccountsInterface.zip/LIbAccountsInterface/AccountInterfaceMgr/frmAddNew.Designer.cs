﻿namespace AccountInterfaceMgr
{
    partial class frmAddNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddNew));
            this.grpEdit = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.BtnCreateNew = new System.Windows.Forms.Button();
            this.cboAccountType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAccountNo = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.BtnDone = new System.Windows.Forms.Button();
            this.grpEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpEdit
            // 
            this.grpEdit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grpEdit.Controls.Add(this.label4);
            this.grpEdit.Controls.Add(this.BtnCreateNew);
            this.grpEdit.Controls.Add(this.txtAmount);
            this.grpEdit.Controls.Add(this.cboAccountType);
            this.grpEdit.Controls.Add(this.label2);
            this.grpEdit.Controls.Add(this.label1);
            this.grpEdit.Controls.Add(this.txtAccountNo);
            this.grpEdit.Location = new System.Drawing.Point(38, 30);
            this.grpEdit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpEdit.Name = "grpEdit";
            this.grpEdit.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpEdit.Size = new System.Drawing.Size(277, 241);
            this.grpEdit.TabIndex = 3;
            this.grpEdit.TabStop = false;
            this.grpEdit.Text = "Create an Account";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Amount $";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(135, 129);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(103, 22);
            this.txtAmount.TabIndex = 9;
            // 
            // BtnCreateNew
            // 
            this.BtnCreateNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.BtnCreateNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnCreateNew.FlatAppearance.BorderSize = 5;
            this.BtnCreateNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BtnCreateNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Aqua;
            this.BtnCreateNew.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCreateNew.ForeColor = System.Drawing.SystemColors.Control;
            this.BtnCreateNew.Location = new System.Drawing.Point(20, 189);
            this.BtnCreateNew.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnCreateNew.Name = "BtnCreateNew";
            this.BtnCreateNew.Size = new System.Drawing.Size(225, 31);
            this.BtnCreateNew.TabIndex = 7;
            this.BtnCreateNew.Text = "Create New Account";
            this.BtnCreateNew.UseVisualStyleBackColor = false;
            this.BtnCreateNew.Click += new System.EventHandler(this.BtnCreateNew_Click);
            // 
            // cboAccountType
            // 
            this.cboAccountType.FormattingEnabled = true;
            this.cboAccountType.Location = new System.Drawing.Point(133, 42);
            this.cboAccountType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboAccountType.Name = "cboAccountType";
            this.cboAccountType.Size = new System.Drawing.Size(104, 24);
            this.cboAccountType.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Account #";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Account Type";
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.Location = new System.Drawing.Point(134, 81);
            this.txtAccountNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(103, 22);
            this.txtAccountNo.TabIndex = 0;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(348, 49);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(142, 143);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            // 
            // BtnDone
            // 
            this.BtnDone.BackColor = System.Drawing.Color.Blue;
            this.BtnDone.ForeColor = System.Drawing.Color.White;
            this.BtnDone.Location = new System.Drawing.Point(377, 219);
            this.BtnDone.Name = "BtnDone";
            this.BtnDone.Size = new System.Drawing.Size(100, 31);
            this.BtnDone.TabIndex = 5;
            this.BtnDone.Text = "Done";
            this.BtnDone.UseVisualStyleBackColor = false;
            this.BtnDone.Click += new System.EventHandler(this.BtnDone_Click);
            // 
            // frmAddNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(523, 287);
            this.Controls.Add(this.BtnDone);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.grpEdit);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmAddNew";
            this.Text = " Add New Account";
            this.Load += new System.EventHandler(this.frmAddNew_Load);
            this.grpEdit.ResumeLayout(false);
            this.grpEdit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpEdit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Button BtnCreateNew;
        private System.Windows.Forms.ComboBox cboAccountType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAccountNo;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button BtnDone;
    }
}