﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkingWithArray
{
    class CopyingArray
    {
        static void Main(string[] args)
        {
            const int SIZE = 5;


            // declare and initialize the first array
            int[] array1 = { 2,4,6,8,10};

            int[] array2 = new int[SIZE];

            // To copy the array1 to array2 first create the array2 in the memory
            // and copy the individual elements of the first array to the second array
            // this best done with a loop.
            
            for (int index = 0; index < array1.Length; index++)
            {
                array2[index] = array1[index];
                
            }

            // to display the content of array use loop to access all value
            // we can use foreach loop also
            // foreach(int itemArray in array2)
            for (int i = 0; i < array2.Length; i++)
            {
                Console.WriteLine(array2[i]);
            }

            Console.ReadLine();


        }
    }
}
