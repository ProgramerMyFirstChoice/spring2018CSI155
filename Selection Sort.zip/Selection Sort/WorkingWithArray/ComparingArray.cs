﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkingWithArray
{
    class ComparingArray
    {
        static void Main(string[] args)
        {
            // arrays
            int[] array1 = { 2, 4, 6, 8, 10 };

            int[] array2 = { 2, 4, 6, 8, 10 };


            // To compare the content of two array , compare the element of the two arrays

            bool arraysEqual = true; // flag variable
            int index = 0;     // To hold array subscripts

            // firs determine whether the arrays are the same data.
            if (array1.Length != array2.Length)
            {
                arraysEqual = false;
            }

            // next determine whether the elements contain the same data
            while (arraysEqual && index < array1.Length )
            {
                if (array1[index] != array2[index])
                {
                    arraysEqual = false;
                }
                index++;
            }// end of while loop return true if the are the same

            if (arraysEqual)
            {
                MessageBox.Show("The arrays are equal");
            }
            else
            {
                MessageBox.Show("The arrays are not equal");
            }
        }
    }
}

